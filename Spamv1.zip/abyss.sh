#!/system/xbin/bash
#abysswalker
#recodelu_memang_nub


blue='\033[34;1m'
green='\033[32;1m'
purple='\033[35;1m'
cyan='\033[36;1m'
red='\033[31;1m'
white='\033[37;1m'
yellow='\033[33;1m'
sleep 1

line="\e[1;31m[@]\e[0m"

clear
cd module
python2 p.py
bash r.sh


toilet --metal -f future -t "  Welcome Back"
toilet --metal -f small -t " Abyss Walker"
echo ""
echo -e "$line Welcome To Mix Tools Spammer"
echo ""
echo -e "$line Big Thanks To All Authors!!"
echo -e ""
echo "<====================================================>"
echo -e "$line Youtube    : Abyss Walker"
echo -e "$line Facebook   : Abyss Project"
echo -e "$line Instagram  : abysswalker260"
date
echo "<====================================================>"

echo -e "$green Pilih Tools Yang Mau Kalian Install"
echo -e "$red 1. Spam Sms V1"
echo -e "$green ____________________________"
echo -e "$red 2. Spam Sms V2"
echo -e "$green ____________________________"
echo -e "$red 3. Spam Sms V3"
echo -e "$green ____________________________"
echo -e "$cyan 4. Spam Facebook v1"
echo -e "$green ____________________________"
echo -e "$cyan 5. Spam Facebook v2"
echo -e "$green ____________________________"
echo -e "$cyan 6. Spam Facebook v3"
echo -e "$green ____________________________"
echo -e "$purple 7. Spam Gmail V1 "
echo -e "$green ____________________________"
echo -e "$purple 8. Spam Gmail V2 "
echo -e "$green ____________________________"
echo -e "$purple 9. Spam Gmail V3 "
echo -e "$green ____________________________"
echo -e "$red 10. Spam Sms/Email/Whatsapp (Bisa Pilih Sendiri)"
echo -e "$green ____________________________"
echo -e "$yellow 11. Spam Whatsapp V1"
echo -e "$green ____________________________"
echo -e "$yellow 12. Spam Whatsapp V2"
echo -e "$green ____________________________"
echo -e "$blue 0. Keluar"

read -p "Root@AbyssWalker ~# " asu

if [ $asu = 1 ] || [ $asu = 1 ]
then
clear
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
apt install git                                               git clone https://github.com/storiku/instahack
git clone https://github.com/TheSpeedX/TBomb
mv TBomb $HOME
cd $HOME/TBomb
bash TBomb.sh
fi

if [ $asu = 2 ] || [ $asu = 2 ]
then                                                              clear
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
git clone https://github.com/KANG-NEWBIE/SpamSms
pip install requests mechanize bs4
mv SpamSms $HOME
cd $HOME/SpamSms
python main.py
fi

if [ $asu = 3 ] || [ $asu = 3 ]
then
clear
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
git clone https://github.com/4nat/Reborn/
mv Reborn $HOME
cd $HOME/Reborn
bash start.sh
fi

if [ $asu = 4 ] || [ $asu = 4 ]
then
clear
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
git clone https://github.com/errorBrain/spamchat.git
mv spamchat $HOME
cd $HOME/spamchat
pip2 install -r requirements.txt
python2 messenger.py
fi

if [ $asu = 5 ] || [ $asu = 5 ]
then
clear
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
git clone https://github.com/pashayogi/Fbspam
mv Fbspam $HOME
cd $HOME/Fbspam
unzip Fbspam.zip
python2 fbspam.py
fi

if [ $asu = 6 ] || [ $asu = 6 ]
then
clear
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
apt install git
git clone https://github.com/iamgroot42/fb_spammer
mv fb_spammer $HOME
cd $HOME/fb_spammer
python spammer.py
fi

if [ $asu = 7 ] || [ $asu = 7 ]
then
clear
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
git clone https://github.com/Juniorn1003/Email-Spammer
mv Email-Spammer $HOME
cd $HOME/Email-Spammer
bash install.sh
python2 Email-Spam.py
fi

if [ $asu = 8 ] || [ $asu = 8 ]
then
clear
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
git clone https://github.com/mohinparamasivam/Email_Bomber.git
mv Email-Bomber $HOME
cd $HOME/Email-Bomber
python2 emailbomber.py
fi

if [ $asu = 9 ] || [ $asu = 9 ]
then
clear
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
git clone https://github.com/revan-ar/mail-spammer
mv mail-spammer $HOME
cd $HOME/mail-spammer
php mail.php
fi

if [ $asu = 10 ] || [ $asu = 10 ]
then
clear
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
git clone https://github.com/bhattsameer/Bombers
mv Bombers $HOME
cd $HOME/Bombers
ls
fi

if [ $asu = 11 ] || [ $asu = 11 ]
then
clear
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
git clone https://github.com/TH3-MA3STRO/whatsapp-spammer
mv whatsapp-spammer $HOME
cd $HOME/whatsapp-spammer
pip install -r requirements.txt
python spammer.py
fi


if [ $asu = 12 ] || [ $asu = 12 ]
then
clear
figlet Darknet | lolcat
echo "Untuk Tutorial Silahkan Comment Atau Join Grup"
sleep 3
apt update
apt upgrade
apt install git
git clone https://github.com/XiuzCode/k-bisa-otp-v2
mv k-bisa-otp-v2 $HOME
cd $HOME/k-bisa-otp-v2
python kitabis.py
fi

if [ $asu = 0 ] || [ $asu = 0 ]
then
echo -e "$green Thanks To Use This Tools"
echo -e "$green By Abyss Walker"
exit
fi
clear
