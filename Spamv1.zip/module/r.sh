#!/system/xbin/bash
#abysswalker
#recodelu_memang_nub

line="\e[1;31m[@]\e[0m"

clear
toilet --metal -f future " Welcome Back"
sleep 1
toilet --metal -f future " To"
sleep 1
toilet --metal -f future " MixTools"
sleep 1
toilet --metal -f future " Spammer"
sleep 1
clear
toilet --metal -f small " Abyss Walker"
sleep 1
clear





echo -e "$line Please Wait"
echo -e "$line Checking Server"
sleep 1
echo -e "." | lolcat
echo -e ".." | lolcat
echo -e "..." | lolcat
echo -e "...." | lolcat
echo -e "....." | lolcat
echo ""
echo -e "$line All Tools Up To Date"
echo -e "$line DONE!"
echo -e "$line Enjoy!"
sleep 2
clear

